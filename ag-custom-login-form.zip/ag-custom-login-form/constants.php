<?php

define('AG_CUSTOM_LOGIN_FORM_DEBUG', 0);

define('AG_CUSTOM_LOGIN_FORM_LOGGING', 1);

define('AG_CUSTOM_LOGIN_FORM_PLUGIN_DIR', plugin_dir_path(__FILE__));