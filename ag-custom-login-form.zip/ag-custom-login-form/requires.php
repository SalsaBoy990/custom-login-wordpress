<?php

// constants
require_once 'autoload.php';

// constants
require_once 'constants.php';
