# custom-login-wordpress
Wordpress plugin. Add customizable login/register forms into page/post, customize wp-login page.
